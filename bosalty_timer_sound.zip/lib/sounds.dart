import 'package:audioplayers/audioplayers.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import 'state.dart';
import 'ui.dart';

/// One tone the user can pick for the end of a focus session.
class TimerSound {
  const TimerSound(this.id, this.ar, this.en);
  final String id, ar, en;

  /// 'system' = the phone's own default notification sound (no file).
  bool get isSystem => id == 'system';

  /// Path for audioplayers (relative to the assets/ folder).
  String get asset => 'sounds/timer_$id.wav';
}

class TimerSounds {
  static const defaultId = 'chime';
  static const all = [
    TimerSound('chime', 'رنّة رقيقة', 'Soft chime'),
    TimerSound('bell', 'جرس', 'Bell'),
    TimerSound('marimba', 'ماريمبا', 'Marimba'),
    TimerSound('digital', 'منبّه رقمي', 'Digital alarm'),
    TimerSound('calm', 'هادئة', 'Calm'),
    TimerSound('bowl', 'طاسة تأمّل', 'Singing bowl'),
    TimerSound('system', 'نغمة الموبايل الافتراضية', 'Phone default'),
  ];

  static TimerSound? byId(String? id) {
    for (final s in all) {
      if (s.id == id) return s;
    }
    return null;
  }

  static AudioPlayer? _player;
  static bool _ctxSet = false;

  /// Plays a tone inside the app (preview in settings, and the finish sound on Windows / web).
  static Future<void> play(String id) async {
    try {
      final s = byId(id) ?? byId(defaultId)!;
      if (s.isSystem) {
        await SystemSound.play(SystemSoundType.alert);
        return;
      }
      final p = _player ??= AudioPlayer();
      if (!_ctxSet) {
        _ctxSet = true;
        // lower the Quran radio for a moment instead of stopping it
        await p.setAudioContext(AudioContextConfig(focus: AudioContextConfigFocus.duckOthers).build());
      }
      await p.stop();
      await p.play(AssetSource(s.asset));
    } catch (e) {
      debugPrint('TimerSounds.play error: $e');
    }
  }

  static Future<void> stop() async {
    try {
      await _player?.stop();
    } catch (_) {}
  }
}

/// Drop this into the Settings screen: a list of tones, tap one to select it and hear it.
class TimerSoundPicker extends StatelessWidget {
  const TimerSoundPicker({super.key});

  @override
  Widget build(BuildContext context) {
    final s = AppScope.of(context);
    final p = s.pal;
    final cur = s.timerSoundId;
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Txt(s.rtl ? 'رنّة نهاية جلسة التركيز' : 'Focus session end tone', size: 15, bold: true),
        const SizedBox(height: 8),
        for (final o in TimerSounds.all)
          Padding(
            padding: const EdgeInsets.only(bottom: 6),
            child: InkWell(
              borderRadius: BorderRadius.circular(12),
              onTap: () {
                s.setTimerSound(o.id);
                TimerSounds.play(o.id);
              },
              child: Container(
                padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
                decoration: BoxDecoration(
                  color: o.id == cur ? p.sel : p.card2,
                  borderRadius: BorderRadius.circular(12),
                  border: Border.all(color: o.id == cur ? p.accent : Colors.transparent),
                ),
                child: Row(children: [
                  Icon(
                    o.id == cur ? Icons.radio_button_checked_rounded : Icons.radio_button_off_rounded,
                    color: o.id == cur ? p.accent : p.muted,
                    size: 20,
                  ),
                  const SizedBox(width: 10),
                  Expanded(child: Txt(s.rtl ? o.ar : o.en, size: 14, bold: o.id == cur)),
                  Icon(Icons.volume_up_rounded, color: p.muted, size: 18),
                ]),
              ),
            ),
          ),
      ],
    );
  }
}
